package com.hekkelman.keylocker.datamodel;

/**
 * Created by maarten on 24-11-15.
 */
public class KeyDbException extends Exception {
}
