package com.hekkelman.keylocker.datamodel;

/**
 * Created by maarten on 24-11-15.
 */
public class InvalidFileException extends KeyDbException {
    public InvalidFileException() {
    }
}
